GRID_COLOR = "#000000"
CouleurCellule = "#fefee0"
Score_label = ("Verdana",24)
Score_font = ("Helvetica",36,"bold")
Fin_game_font = ("Helvetica",48,"bold")
Fin_game_couleur = "#ffffff"
Gagner_couleur = "#2af44"
Echec_color = "#ff0000"

Couleurs_DES_cellules = {
    2: "#b5a5cd",
    4: "#8e75b3",
    8: "#77b5fe",
    16: "#dda0dd",
    32: "#0131b4",
    64:  "#6c0277",
    128: "#0000ff",
    256:  "#005df1",
    512: "#449aff",
    1024: "#44ffd8",
    2048: "#2c75ff"
}
Couleurs_Nombre_cell = {
    2: "#ffffff",
    4: "#ffffff",
    8: "#ffffff",
    16: "#ffffff",
    32: "#ffffff",
    64: "#ffffff",
    128: "#ffffff",
    256: "#ffffff",
    512: "#ffffff",
    1024: "#ffffff",
    2048: "#ffffff" 
}
font_nombre_cellule = {
    2: ("Helvetica",55,"bold"),
    4: ("Helvetica",55,"bold"),
    8: ("Helvetica",55,"bold"),
    16: ("Helvetica",50,"bold"),
    32: ("Helvetica",50,"bold"),
    64: ("Helvetica",50,"bold"),
    128: ("Helvetica",40,"bold"),
    256: ("Helvetica",40,"bold"),
    512: ("Helvetica",40,"bold"),
    1024: ("Helvetica",35,"bold"),
    2048: ("Helvetica",35,"bold")
}
