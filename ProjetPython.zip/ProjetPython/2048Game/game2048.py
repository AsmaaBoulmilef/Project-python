import tkinter as tk
import couleurs as coul
import random
import sys


#class for the game
class Game(tk.Frame):
    #constructeur
    def __init__(self):
        tk.Frame.__init__(self)
        self.grid()
        #the title
        self.master.title("2048 Ilisi")
        #Construct a frame widget 
        self.main_grid = tk.Frame (self,bg=coul.GRID_COLOR,bd=3, width=600,height=500)
        self.main_grid.grid(pady=(100,0))
        self.Interface()
        self.start_game()
        #Create the buttons to play
        self.master.bind("<Left>", self.left)
        self.master.bind("<Right>", self.right)
        self.master.bind("<Up>", self.up)
        self.master.bind("<Down>", self.down)

        self.mainloop()
    
    def Interface(self):
        #draw grid
        self.cells = []
        for i in range(4):
            row = []
            for j in range(4):
                cell_fram = tk.Frame(self.main_grid,bg=coul.CouleurCellule,width=100,height=100)
                cell_fram.grid(row=i, column=j, padx=5,pady=5)
                cell_number = tk.Label(self.main_grid, bg=coul.CouleurCellule)
                cell_number.grid(row=i,column=j)
                cell_data = {"frame": cell_fram, "number": cell_number}
                row.append(cell_data)
            self.cells.append(row)
        #Score
        score_frame = tk.Frame(self)
        score_frame.place(relx=0.5, y=45, anchor="center")
        tk.Label(score_frame,text="Score", font=coul.Score_label).grid(row=0)
        self.Score_label =tk.Label(score_frame, text="0",font=coul.Score_font)
        self.Score_label.grid(row=1)
    #The function is used to initialize the matrix and randomly put the number 2 in the cells.
    def start_game(self):
        #Create the matrix and initialize it with 0
        self.matrice = [[0] * 4 for _ in range(4)]
        #fill in two boxes
        row = random.randint(0,3)
        col = random.randint(0,3)
        self.matrice[row][col] = 2
        #Update the grid
        self.cells[row][col]["frame"].configure(bg=coul.Couleurs_DES_cellules[2])
        self.cells[row][col]["number"].configure(bg=coul.Couleurs_DES_cellules[2],fg=coul.Couleurs_Nombre_cell[2],font=coul.font_nombre_cellule[2],text="2")
        while(self.matrice[row][col] != 0):
            row = random.randint(0,3)
            col = random.randint(0,3)
        self.matrice[row][col] = 2
        self.cells[row][col]["frame"].configure(bg=coul.Couleurs_DES_cellules[2])
        self.cells[row][col]["number"].configure(bg=coul.Couleurs_DES_cellules[2],fg=coul.Couleurs_Nombre_cell[2],font=coul.font_nombre_cellule[2],text="2")
        self.score = 0
     


    def stack(self):
        new_matrice = [[0] * 4 for _ in range(4)]
        for i in range(4):
            fill_position = 0
            for j in range(4):
                if self.matrice[i][j] != 0:
                    new_matrice[i][fill_position] = self.matrice[i][j]
                    fill_position = fill_position + 1
        self.matrice = new_matrice
    #This function is used to combine two boxes if they have the same value
    def combine(self):
        for i in range(4):
            for j in range(3):
                if self.matrice[i][j] != 0  and self.matrice[i][j] == self.matrice[i][j+1]:
                    self.matrice[i][j] *= 2
                    self.matrice[i][j + 1] = 0
                    self.score = self.score + self.matrice[i][j]
    
    def reverse(self):
        new_matrice = []
        for i in range(4):
            new_matrice.append([])
            for j in range(4):
                new_matrice[i].append(self.matrice[i][3 - j])
        self.matrice = new_matrice

    def transpose(self):
        new_matrice = [[0] * 4 for _ in range(4)]
        for i in range(4):
            for j in range(4):
                new_matrice[i][j] = self.matrice[j][i]
        self.matrice = new_matrice
    
    #Add a new random number to the grid.
    def add_new_title(self):
        row = random.randint(0, 3)
        col = random.randint(0, 3)
        while(self.matrice[row][col] != 0):
            row = random.randint(0, 3)
            col = random.randint(0, 3)
        self.matrice[row][col] = random.choice([2, 4])
    
    #Update the interface
    def mise_a_jour_interface(self):
        for i in range(4):
            for j in range(4):
                val = self.matrice[i][j]
                #if the box is empty
                if val == 0:
                    self.cells[i][j]["frame"].configure(bg=coul.CouleurCellule)
                    self.cells[i][j]["number"].configure(bg=coul.CouleurCellule, text="")
                else:
                    self.cells[i][j]["frame"].configure(bg=coul.Couleurs_DES_cellules[val])
                    self.cells[i][j]["number"].configure(
                        bg=coul.Couleurs_DES_cellules[val],
                        fg=coul.Couleurs_Nombre_cell[val],
                        font=coul.font_nombre_cellule[val],
                        text=str(val)
                    )
        self.Score_label.configure(text=self.score)
        #Force the display to be updated.
        self.update_idletasks()
    #button left
    def left(self,event):
        self.stack()
        self.combine()
        self.stack()
        self.add_new_title()
        self.mise_a_jour_interface()
        self.game_over()
    #button right
    def right(self,event):
        self.reverse()
        self.stack()
        self.combine()
        self.stack()
        self.reverse()
        self.add_new_title()
        self.mise_a_jour_interface()
        self.game_over()
    #button up
    def up(self,event):
        self.transpose()
        self.stack()
        self.combine()
        self.stack()
        self.transpose()
        self.add_new_title()
        self.mise_a_jour_interface()
        self.game_over()
    #button down
    def down(self,event):
        self.transpose()
        self.reverse()
        self.stack()
        self.combine()
        self.stack()
        self.reverse()
        self.transpose()
        self.add_new_title()
        self.mise_a_jour_interface()
        self.game_over()
    
    #This function allows  to search horizontally if there are two horizontal boxes with the same value.
    def chercher_horizontal(self):
        for i in range(4):
            for j in range(3):
                if self.matrice[i][j] == self.matrice[i][j + 1]:
                    return True
                else:
                    print("miw")

        return False
        
    #This function allows  to search vertically if there are two vertical boxes with the same value.
    def chercher_verticale(self):
        for i in range(3):
            for j in range(4):
                if self.matrice[i][j] == self.matrice[i + 1][j]:
                    self.combine()
                    return True
                else:
                    print("piw")
        return False
    


        
    
    #This function allows  to test if the game is over.
    def game_over(self):
        print("fiw")
        #First we test if there is a cell in the grid that has a value of 2048 then the player wins.
        if any(2048 in row for row in self.matrice):
            game_over_frame = tk.Frame(self.main_grid, borderwidth=2)
            game_over_frame.place(relx=0.5, rely=0.5, anchor="center")
            tk.Label(
                game_over_frame,
                text="You win!",
                bg=coul.Gagner_couleur,
                fg=coul.Fin_game_couleur,
                font=coul.Fin_game_font
            ).pack()
        #Otherwise we test if there are no cells to combine then the player loses.
        elif not any(0 in row for row in self.matrice):
            if self.chercher_horizontal() == False and self.chercher_verticale()==False:
                game_over_frame = tk.Frame(self.main_grid, borderwidth=2)
                game_over_frame.place(relx=0.5, rely=0.5, anchor="center")
                tk.Label(
                  game_over_frame,
                  text="Game over!",
                  bg=coul.Echec_color,
                  fg=coul.Fin_game_couleur,
                  font=coul.Fin_game_font
                ).pack()
            else:
                pass
            
            


if __name__ == "__main__":
    Game()

    




    