import random
import math
import os
from pygame.locals import *
import sys
from initializeGame import *
   

#Player
class Player:
    def __init__(self, x, y, xchange, ychange, img, mybul):
        self.playerX = x  # coordinates (x,y)
        self.playerY = y
        self.playerX_change = xchange 
        self.playerY_change = ychange
        self.lives = 3        # three chances to stay in life
        self.playerImg = img  # image of player
        self.score_value = 0  # score
        self.bullet = mybul   # bullet(fire)

# update player mouvement in screen
    def show(self, x, y):
        screen.blit(self.playerImg, (x, y)) #Draw one image onto another


# Enemies Group
class EnemiesGroup:
    def __init__(self):
        self.enemyImg = []      # enemies images
        self.enemyX = []        # coordinate x
        self.enemyY = []        # coordinate y
        self.enemyX_change = []
        self.enemyY_change = []
        self.enemyScoring = []  # score that win by player if he kill this enemy

# update enemy mouvement in screen  
    def show_enemy(self, i):
        screen.blit(self.enemyImg[i], (enms.enemyX[i], enms.enemyY[i]))



# enemy fire ball
class FiresEnemies:
    def __init__(self):
        self.fireImg = pygame.transform.scale(pygame.image.load("./assests/img/" + "enemy_fire.png"), (24, 24))
        self.fireX = []
        self.fireY = []
        self.fire_state = []
        self.number_of_fires = 3  # these will increase as level goes up
        self.time_interval_between_fires = 2  # this will decrease as level goes up (2 secondes)
        self.starting_time_for_fire = pygame.time.get_ticks() #returns the number of milliseconds since pygame.init() was called

# update fire mouvement in screen   
    def fire_by_enemy(self, x, y):
        screen.blit(self.fireImg, (x + 14, y + 17))



# Bullet
# ready state : you cannot see bullet on screen
# fire state  : bullet is currently moving
class Bullet:
    def __init__(self):
        self.bulletX = 2000
        self.bulletY = 2000
        self.bulletX_change = 0
        self.bulletY_change = 6
        self.bullet_state = "ready"
        self.bulletImg = pygame.image.load("./assests/img/bullet.png")

# update bullet mouvement in screen 
    def fire_bullet(self, p):
        p.bullet.bullet_state = "fire"
        screen.blit(p.bullet.bulletImg, (self.bulletX + 16, self.bulletY + 10))



#contain static functions of services
class Services:

# enemy respawning random coordinates (x, y)
    @staticmethod
    def respawn_coor_x():
        return random.randint(0, 730) # get random int between 0 and 730

    @staticmethod
    def respawn_coor_y(x):
        #return random.randint(-100, 20) - x
        return random.randint(0, 20) - (x*30)

# show score   
    @staticmethod
    def show_score( x, y, valeur):
        score = font.render("Score: " + str(valeur), True, (128, 128, 128)) # return text with color and font text 
        screen.blit(score, (x, y))

# show lives
    @staticmethod
    def show_lives( x, y, valeur):
        # score color will be red if lives == 1 (stay one life)
        if valeur == 1:
            clr = (255,0,0) # RED
        else:
            clr = (0,255,0) # GREEN
        vies = font.render("Lives: " + str(valeur), True, clr)
        screen.blit(vies, (x, y))

#show level
    @staticmethod
    def show_level( x, y):
        lvl = font.render("Level: " + str(level), True, (128, 128, 128))
        screen.blit(lvl, (x, y))

# update score and display game over interface
    @staticmethod
    def game_over_text():
        p1.score_value -= ((3 - p1.lives)*30)
        p2.score_value -= ((3 - p2.lives)*30)
        if(p1.score_value < 0):
            p1.score_value = 0
        if(p2.score_value < 0):
           p2.score_value = 0
        
        # effacer le contenu du fichier
        open("scores.txt", 'w').close()
        # open file
        f = open("scores.txt", "a")
        f.write(str(p1.score_value) + "\n") # save scores
        f.write(str(p2.score_value))
        f.close()
        mixer.music.stop()             # stop music
        
#test collision
    @staticmethod
    def isCollision(enX, enY, bulX, bulY):
        distance = math.sqrt((math.pow((enX - bulX), 2)) + (math.pow((enY - bulY), 2)))
        if distance < 27:
            screen.blit(boom, (enX, enY))    # display a boom image
            pygame.display.flip()            # Update the full display Surface to the screen
            pygame.time.Clock().tick(100)    # Réglage d'images par seconde (stop game with a time)
            return True
        else:
            return False  # not colision

# update level
    @staticmethod
    def level_up():
        global level
        global ENEMY_MOVEMENT_X
        ENEMY_MOVEMENT_X += 0.3  # enemies will be quick 
        fires.time_interval_between_fires -= 1  # increment time interval between fires
        fires.number_of_fires += 3              # increment number of fires
        level += 1    # level up

        # add new enemy with a hight score
        if level == 2:
            enms.enemyImg[0] = pygame.image.load("./assests/img/mystery.png")
            enms.enemyImg[0] = pygame.transform.scale(enms.enemyImg[0], (100, 50))
            enms.enemyScoring[0] = 100 
            # change fire image (green)
            fires.fireImg = pygame.image.load("./assests/img/mystery_fire.png")
            fires.fireImg = pygame.transform.scale(fires.fireImg, (24, 24))



# initialize enemies and their fires
    @staticmethod
    def init_enemy_with_fires():
    
        for i in range(number_of_enemies):
            choice = random.randint(1, 6)  # choice an enemy
            NameImg = "enemy" + str(choice) + ".png" # charge image
            enms.enemyImg.append(pygame.image.load("./assests/img/" + NameImg))
            enms.enemyImg[i] = pygame.transform.scale(enms.enemyImg[i], (50, 50)) # add image
            enms.enemyScoring.append( choice*10 )  # add score
            
        # random enemy coordinates
            x = Services.respawn_coor_x()
            y = Services.respawn_coor_y(i)
            enms.enemyX.append(x) # add enemy coordinate x,y
            enms.enemyY.append(y)
            fires.fireX.append(x) # add fire coordinate x,y
            fires.fireY.append(y)
            enms.enemyX_change.append(ENEMY_MOVEMENT_X)
            enms.enemyY_change.append(35)
            fires.fire_state.append("ready") # set fire ready

#Init Enemies Group
enms = EnemiesGroup()

# init fires enemies
fires = FiresEnemies()

#define gloabl variable
clicked = False

#Bullets players
b1 = Bullet()
b2 = Bullet()

#Players
p1 = Player(400, 530, 0, 0, playerImg, b1)
p2 = Player(200, 530, 0, 0, playerImg2, b2)

Services.init_enemy_with_fires()

