import pygame
import random

WIDTH = 360
HEIGHT = 480
FPS = 30

# definir des couleurs : 
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)
VIOLET = (255,0,255)
MAGENTA = (0,255,255)


# initialiser pygame : 
pygame.init()
pygame.mixer.init()
# creation de la fenetre : 
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("My Game")
clock = pygame.time.Clock()

all_sprites = pygame.sprite.Group()

# la boucle du jeu : 
running = True
while running:
    
    # keep loop running at the right speed : 
    clock.tick(FPS)

    # events:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # update : 
    all_sprites.update()

    # draw /  render : 
    screen.fill(BLACK)
    all_sprites.draw(screen)
    
    # after drawing everything, flip the display : 
    pygame.display.flip()

pygame.quit()