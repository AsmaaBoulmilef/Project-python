from game import *


# Game loop
running = True
while running:  
    
    # background image
    screen.blit(backgroundImg, (0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # quit game
            running = False
        # check if key is pressed
        if event.type == pygame.KEYDOWN:
          # PLAYER 1
            # check if its right key, left key, up key and down key
            if event.key == pygame.K_LEFT:
                p1.playerX_change = -2
            if event.key == pygame.K_RIGHT:
                p1.playerX_change = 2
            if event.key == pygame.K_UP:
                p1.playerY_change = -2
            if event.key == pygame.K_DOWN:
                p1.playerY_change = 2
          # PLAYER 2
            # check if its q key, s key, d key and z key
            if event.key == pygame.K_q: 
                p2.playerX_change = -2
            if event.key == pygame.K_d: 
                p2.playerX_change = 2
            if event.key == pygame.K_z: 
                p2.playerY_change = -2
            if event.key == pygame.K_s: 
                p2.playerY_change = 2
            # check if its space key (tire player 1)
            if event.key == pygame.K_SPACE:
                if p1.bullet.bullet_state == "ready":
                    bullet_sound = mixer.Sound("./assests/sounds/shoot.wav")
                    bullet_sound.play() # play sound tire
                    # get the current x coordinate of spaceship
                    p1.bullet.bulletX = p1.playerX
                    p1.bullet.bulletY = p1.playerY
                    p1.bullet.fire_bullet(p1)  # update bullet mouvement player 1
            # check if its x key (tire player 2)
            if event.key == pygame.K_x:
                if p2.bullet.bullet_state == "ready":
                    bullet_sound = mixer.Sound("./assests/sounds/shoot.wav")
                    bullet_sound.play()
                    # get the current x coordinate of spaceship
                    p2.bullet.bulletX = p2.playerX
                    p2.bullet.bulletY = p2.playerY
                    p2.bullet.fire_bullet(p2) # update bullet mouvement player 2
        # check if key is released
        elif event.type == pygame.KEYUP:
        # Reset change X and Y 
          # PLAYER 1
            if event.key == pygame.K_LEFT:
                p1.playerX_change = 0
            if event.key == pygame.K_RIGHT:
                p1.playerX_change = 0
            if event.key == pygame.K_UP:
                p1.playerY_change = 0
            if event.key == pygame.K_DOWN:
                p1.playerY_change = 0
          # PLAYER 2
            if event.key == pygame.K_q: # player 2
                p2.playerX_change = 0
            if event.key == pygame.K_d: 
                p2.playerX_change = 0
            if event.key == pygame.K_z: 
                p2.playerY_change = 0
            if event.key == pygame.K_s: 
                p2.playerY_change = 0

    # players movement
    p1.playerX += p1.playerX_change
    p1.playerY += p1.playerY_change

    p2.playerX += p2.playerX_change
    p2.playerY += p2.playerY_change

    # Boundaries (Limite des joueurs)
    # Player 1
    if p1.playerX <= 0:
        p1.playerX = 0
    if p1.playerX > 736:
        p1.playerX = 736
    if p1.playerY <= 0:
        p1.playerY = 0
    if p1.playerY > 530:
        p1.playerY = 530
    
    # Player 2
    if p2.playerX <= 0:
        p2.playerX = 0
    if p2.playerX > 736:
        p2.playerX = 736
    if p2.playerY <= 0:
        p2.playerY = 0
    if p2.playerY > 530:
        p2.playerY = 530

    # check if one track completed then increase level
    if ((pygame.time.get_ticks() - starter_time) / 1000) > 20: # after 20 seconds => level up
        Services.level_up()  
        starter_time = pygame.time.get_ticks() # get new time (current)

    for i in range(number_of_enemies):
        # enemy movement
        enms.enemyX[i] += enms.enemyX_change[i]
        # check if enemy and player collided
        col = Services.isCollision(enms.enemyX[i], enms.enemyY[i], p1.playerX, p1.playerY) 
        col2 = Services.isCollision(enms.enemyX[i], enms.enemyY[i], p2.playerX, p2.playerY)
        if col or col2:
            # collision => decrement lives
            if col :
                p1.lives -= 1
            else:
                p2.lives -= 1
           # lives(player 1 or 2) is null so game over
            if(p1.lives == 0 or p2.lives == 0):
                pygame.display.quit()
                Services.game_over_text()
                os.system('python gameover.py')
                sys.exit()
            
                
        # get to the left
        if enms.enemyX[i] <= 0:
            enms.enemyX_change[i] = ENEMY_MOVEMENT_X
            enms.enemyY[i] += enms.enemyY_change[i]
        # get to the right
        if enms.enemyX[i] > 730:
            enms.enemyX_change[i] = -ENEMY_MOVEMENT_X
            enms.enemyY[i] += enms.enemyY_change[i]
        #arriver a la fin => debuter
        # get to the bottom => top
        if enms.enemyY[i] > 480:
            enms.enemyY[i] = Services.respawn_coor_y(i)

        # test collision enemy and bullet (player 1)
        collision = Services.isCollision(enms.enemyX[i], enms.enemyY[i], p1.bullet.bulletX, p1.bullet.bulletY)
        if collision:

            p1.bullet.bulletY = p1.playerY         # reset y of bullet
            p1.bullet.bullet_state = "ready"       # set bullet ready
            p1.score_value += enms.enemyScoring[i] # add score

        # test collision enemy and bullet (player 2)  
        collision2 = Services.isCollision(enms.enemyX[i], enms.enemyY[i], p2.bullet.bulletX, p2.bullet.bulletY)
        if collision2:
           
            p2.bullet.bulletY = p2.playerY
            p2.bullet.bullet_state = "ready"
            p2.score_value += enms.enemyScoring[i]
            
        if collision or collision2:
            enemy_destroy = mixer.Sound("./assests/sounds/explosion.wav") # charge explosion sound 
            enemy_destroy.play()  # play sound (enemy is dead ^_^)
            # Renaissance enemy
            enms.enemyX[i] = Services.respawn_coor_x()
            enms.enemyY[i] = Services.respawn_coor_y(i)
        enms.show_enemy(i) # show this enemy

    # check if previous bullet is out of screen
    # PLAYER 1
    if p1.bullet.bulletY <= 0:
        p1.bullet.bulletY = p1.playerY
        p1.bullet.bullet_state = "ready"
    # bullet player 1 movement
    if p1.bullet.bullet_state == "fire":
        p1.bullet.fire_bullet(p1) # show bullet
        p1.bullet.bulletY -= p1.bullet.bulletY_change

    # PLAYER 2
    if p2.bullet.bulletY <= 0:
        p2.bullet.bulletY = p2.playerY
        p2.bullet.bullet_state = "ready"
    # bullet player 2 movement
    if p2.bullet.bullet_state == "fire":
        p2.bullet.fire_bullet(p2) # show bullet
        p2.bullet.bulletY -=  p2.bullet.bulletY_change

    # check time between fires(enemies)
    if ((pygame.time.get_ticks() - fires.starting_time_for_fire) / 1000) > fires.time_interval_between_fires:
        fires.starting_time_for_fire = pygame.time.get_ticks() # take last fire
        for i in range(fires.number_of_fires):
         # set fire ready => fire
            if fires.fire_state[i] == "ready" and enms.enemyY[i] > 0:
                fires.fireX[i] = enms.enemyX[i] # update coordonates
                fires.fireY[i] = enms.enemyY[i]
                fires.fire_by_enemy(fires.fireX[i], fires.fireY[i]) # show in screen
                fires.fire_state[i] = "fire"

    #collision player and enemy fire 
    for i in range(number_of_enemies):
        if fires.fire_state[i] == "fire" and enms.enemyY[i] > 0:
            fires.fire_by_enemy(fires.fireX[i], fires.fireY[i]) # show fire 
            fires.fireY[i] += 3        # move fire
            hit_player1 = Services.isCollision(p1.playerX, p1.playerY, fires.fireX[i], fires.fireY[i]) 
            hit_player2 = Services.isCollision(p2.playerX, p2.playerY, fires.fireX[i], fires.fireY[i])
        # check collision
            if hit_player1 or hit_player2:
                fires.fireY[i] = 2000     # disappear fire (out of screen)
                player_killed = mixer.Sound("./assests/sounds/invaderkilled.wav")
                player_killed.play()  # play killed sound
                
                if hit_player1:
                    p1.lives -= 1
                else:
                    p2.lives -= 1
                
                if(p1.lives == 0 or p2.lives == 0):
                    pygame.display.quit()
                    Services.game_over_text()
                    os.system('python gameover.py')
                    sys.exit()
                    
                    
        # fire is out => ready
        if fires.fireY[i] > 800:
            fires.fire_state[i] = "ready"

    # Show players
    p1.show(p1.playerX, p1.playerY)
    p2.show(p2.playerX, p2.playerY)
    # Show their scores and lives
    Services.show_score(10, 20, p2.score_value)
    Services.show_lives(10, 60, p2.lives)
    Services.show_score(670, 20, p1.score_value)
    Services.show_lives(670, 60, p1.lives)
    # Show level
    Services.show_level(360, 280)
    # Update all parts of screen
    pygame.display.update()
