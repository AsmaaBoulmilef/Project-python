import os
import pygame
import random
import sys


WIDTH = 1080
HEIGHT = 720
FPS = 30

# dossiers : 
game_folder = os.path.dirname(__file__)
images_folder = os.path.join(game_folder,"images")

# definir des couleurs : 
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)
VIOLET = (255,0,255)
MAGENTA = (0,255,255)

# function hoovering on rect : 
def _on_rect(x,y,lx,rx,uy,dy):
    if(x in range(lx,rx)) and (y in range(uy,dy)):
        return True
    return False

# initialiser pygame : 
pygame.init()
pygame.mixer.init()
# creation de la fenetre : 
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("K-H-A-M-A")
clock = pygame.time.Clock()

# images : 
project_icon = pygame.image.load(os.path.join(images_folder,"projct_icon.png")).convert()
project_icon.set_colorkey(BLACK)
#project_icon = pygame.transform.scale(project_icon,(150,150))
background = pygame.image.load(os.path.join(images_folder,"bg.png")).convert()
yellow_bg = pygame.image.load(os.path.join(images_folder,"yellowbg.png")).convert()
games = []
games_rect = []
games_icons = []
games_icons_rect = []
for i in range(5) : 
    w = pygame.image.load(os.path.join(images_folder,"Window.png")).convert()
    w = pygame.transform.scale(w,(160,160))
    w.set_colorkey(BLACK)
    games.append(w)
    wic = pygame.image.load(os.path.join(images_folder,"ic_{}.png".format(i+1))).convert()
    wic = pygame.transform.scale(wic,(150,130))
    games_icons.append(wic)

for i in range(5):
    r = games[i].get_rect()
    games_rect.append(r)
    ric = games_icons[i].get_rect()
    games_icons_rect.append(ric)


games_rect[0].left,games_rect[0].top  = 95, HEIGHT*0.59
games_rect[1].left,games_rect[1].top =  275, HEIGHT*0.59
games_rect[2].left,games_rect[2].top = 455, HEIGHT*0.59
games_rect[3].left,games_rect[3].top = 635, HEIGHT*0.59
games_rect[4].left,games_rect[4].top = 815, HEIGHT*0.59

games_icons_rect[0].left,games_icons_rect[0].top  = 100, HEIGHT*0.623
games_icons_rect[1].left,games_icons_rect[1].top =  280, HEIGHT*0.623
games_icons_rect[2].left,games_icons_rect[2].top = 460, HEIGHT*0.623
games_icons_rect[3].left,games_icons_rect[3].top = 640, HEIGHT*0.623
games_icons_rect[4].left,games_icons_rect[4].top = 820, HEIGHT*0.623

help_bg = pygame.image.load(os.path.join(images_folder,"help.png")).convert()
help_bg = pygame.transform.scale(help_bg,(80,80))
help_bg.set_colorkey(BLACK)
help_bg_rect = help_bg.get_rect()
help_bg_rect.centerx , help_bg_rect.top = WIDTH/2 -10 ,600

pygame.display.set_icon(project_icon)
all_sprites = pygame.sprite.Group()

# la boucle du jeu : 
hoovering_on_game = False
hoovering_on_rect = -1
choosing_game = -1
running = True
while running:
    
    # keep loop running at the right speed : 
    clock.tick(FPS)

    # events:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION :
            x,y = event.pos
            for i in range(5):
                if _on_rect(x,y,games_rect[i].left, games_rect[i].left + games_rect[i].width,
                                      games_rect[i].top, games_rect[i].top + games_rect[i].height):
                    hoovering_on_game = True
                    hoovering_on_rect = i
                    break
                else:
                    hoovering_on_game = False
        if event.type == pygame.MOUSEBUTTONUP : 
            x,y = event.pos

            if help_bg_rect.collidepoint(x,y) : 
                os.system('python help.py')
            else:
                for i in range(5):
                    if _on_rect(x,y,games_rect[i].left, games_rect[i].left + games_rect[i].width,
                                          games_rect[i].top, games_rect[i].top + games_rect[i].height):
                        choosing_game = i
            
                if choosing_game == 0 :
                    os.system('python ilisiShooter.py')
                if choosing_game == 1 :
                    os.system('python tetris/testTetris.py')
                if choosing_game == 2 :
                    os.system('python main.py')
                if choosing_game == 3 :
                    os.system('python 2048Game/game2048.py')
                if choosing_game == 4 :
                    os.system('python reporting_app/gmail.py')
                
                choosing_game = -1
        

    # update : 
    all_sprites.update()

    # draw /  render : 
    screen.fill(BLACK)
    screen.blit(background,(0,0))
    screen.blit(help_bg,help_bg_rect)
    if hoovering_on_game : 
        screen.blit(yellow_bg,(games_rect[hoovering_on_rect].left -5 , games_rect[hoovering_on_rect].top -5))
    for i in range(5):
        screen.blit(games[i],games_rect[i])
        screen.blit(games_icons[i],games_icons_rect[i])
    all_sprites.draw(screen)
    
    # after drawing everything, flip the display : 
    pygame.display.flip()

pygame.quit()
