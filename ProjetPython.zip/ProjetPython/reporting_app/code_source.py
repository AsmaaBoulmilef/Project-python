from tkinter import *
import smtplib
import time
from tkinter import filedialog
from email.message import EmailMessage
import imghdr
from tkinter import ttk
files=[]
def callbackFunc(event):
     global game
     game=combo.get()
def attach():
    filename=filedialog.askopenfilename(initialdir='C:/',title="Select a file")
    files.append(filename)
    resultat.config(fg="green",text="Attached "+str(len(files))+" files")
def send():
    try:
       msg=EmailMessage()
       msg['subject']=subject.get()
       msg['from']=email.get()
       msg['to']=to.get()
       msg.set_content("Game:"+game+"\n"+body.get())
       for filename in files:
           filetype=filename.split('.')
           filetype=filetype[1]
           if filetype=="png" or filetype=="PNG" or filetype=="jpg" or filetype=="JPG":
              with open(filename,"rb") as f:
                   file_data=f.read()
                   image_type=imghdr.what(filename)
              msg.add_attachment(file_data,maintype="image",subtype=image_type,filename=f.name)
           else:
              with open(filename,"rb") as f:
                   file_data=f.read()
              msg.add_attachment(file_data,maintype="application",subtype="octet-stream",filename=f.name)
       if(email.get()==""or password.get()==""or to.get()=="" or subject.get()=="" or body.get()==""):
          #resultat.config(text="All fields required",fg="red")
          popup = Tk()
          popup.wm_title("!")
          label = Label(popup, text="All fields required", font=("Calibri",20),fg="red")
          label.pack(side="top", fill="x", pady=10,padx=10)
          B1 = ttk.Button(popup, text="Okay", command = popup.destroy)
          B1.pack()
          del files[:]
          return
       else:
           server=smtplib.SMTP('smtp.gmail.com',587)
           server.starttls()
           server.login(email.get(),password.get())
           server.send_message(msg)
           #resultat.config(text="Email has been sent",fg="green")
           popup = Tk()
           popup.wm_title("!")
           label = Label(popup, text="Email has been sent", font=("Calibri",20),fg="green")
           label.pack(side="top", fill="x", pady=10,padx=10)
           B1 = ttk.Button(popup, text="Okay", command = popup.destroy)
           B1.pack()
           
           del files[:]
    except Exception as e:
         print(e)
         #resultat.config(text="Error sending email",fg="red")
         popup = Tk()
         popup.wm_title("!")
         label = Label(popup, text="Error sending email", font=("Calibri",20),fg="red")
         label.pack(side="top", fill="x", pady=10,padx=10)
         B1 = ttk.Button(popup, text="Okay", command = popup.destroy)
         B1.pack()

def  reset():
    g_entry.delete(0,"end")
    p_entry.delete(0,"end")
    t_entry.delete(0,"end")
    s_entry.delete(0,"end")
    b_entry.delete(0,"end")
    g_entry.focus()
    combo.current(0)
List=["game1","game2","game3"]
Screen=Tk()
Screen.geometry("850x750")
Screen.title("Email App")
combo=ttk.Combobox(Screen,values=List,height="100",font=("Calibri",20))
combo.current(0)
combo.grid(sticky=N,padx=(250,0),row=6,pady=(20,0))
combo.config(state="readonly")
Label(Screen,text="EMAIL APP",font=("Calibri",30),fg="red").grid(sticky=N,padx=300,pady=10,row=0)
Label(Screen,text="Use the form below to send an email",font=("Calibri",20),fg="blue").grid(sticky=N,padx=100,pady=(175,10),row=0)
#photo = PhotoImage(file = "C:/Users/hp/Desktop/tp android/logo.png")
photo = PhotoImage("logo.png")
Label(Screen,image=photo).grid(sticky=N,padx=350,pady=80,row=0)
Label(Screen,text="Email",fg="black",font=("Calibri",20)).grid(sticky=W,row=1,padx=140)
Label(Screen,text="Password",fg="black",font=("Calibri",20)).grid(sticky=W,row=2,padx=140,pady=(10,0))
Label(Screen,text="To",fg="black",font=("Calibri",20)).grid(sticky=W,row=3,padx=140,pady=(10,0))
Label(Screen,text="Subject",fg="black",font=("Calibri",20)).grid(sticky=W,row=4,padx=140,pady=(10,0))
Label(Screen,text="Body",fg="black",font=("Calibri",20)).grid(sticky=W,row=5,padx=140,pady=(10,0))
Label(Screen,text="Name Of Game",fg="black",font=("Calibri",20)).grid(sticky=W,row=6,padx=140,pady=(10,0))
resultat=Label(Screen,text="",fg="black",font=("Calibri",20))
resultat.grid(sticky=W,row=7,padx=(900,0))
email=StringVar()
password=StringVar()
to=StringVar()
subject=StringVar()
body=StringVar()
frame =Frame(Screen, borderwidth=5, relief=SUNKEN,bg="white")
frame.grid(sticky=N,padx=(250,0),row=1)
g_entry=Entry(frame,textvariable=email,width=34,font=("Calibri",12),relief=FLAT)
g_entry.grid(sticky=W,row=1,padx=(10,0),ipady=10)
frame =Frame(Screen, borderwidth=5, relief=SUNKEN,bg="white")
frame.grid(sticky=N,padx=(250,0),row=2,pady=(10,0))
p_entry=Entry(frame,textvariable=password,show="*",width=34,font=("Calibri",12),relief=FLAT)
p_entry.grid(sticky=W,row=1,padx=(10,0),ipady=10)
frame =Frame(Screen, borderwidth=5, relief=SUNKEN,bg="#EEEEEE")
frame.grid(sticky=N,padx=(250,0),row=3,pady=(10,0))
t_entry=Entry(frame,textvariable=to,width=34,font=("Calibri",12),relief=FLAT)
t_entry.grid(sticky=W,row=1,padx=(10,0),ipady=10)
t_entry.insert(0,"ilisiilisi7@gmail.com")
t_entry.config(state=DISABLED)
frame =Frame(Screen, borderwidth=5, relief=SUNKEN,bg="white")
frame.grid(sticky=N,padx=(250,0),row=4,pady=(10,0))
s_entry=Entry(frame,textvariable=subject,width=34,font=("Calibri",12),relief=FLAT)
s_entry.grid(sticky=W,row=1,padx=(10,0),ipady=10)
frame =Frame(Screen, borderwidth=5, relief=SUNKEN,bg="white")
frame.grid(sticky=N,padx=(250,0),row=5,pady=(10,0))
b_entry=Entry(frame,textvariable=body,width=34,font=("Calibri",12),relief=FLAT)
b_entry.grid(sticky=W,row=1,padx=(10,0),ipady=10)
Button(Screen,text="Send",bg="blue",fg="white",font=("Calibri",20),command=send,width=16).grid(sticky=W,padx=(40,0),row=7,pady=40)
Button(Screen,text="Reset",bg="green",fg="white",font=("Calibri",20),command=reset,width=16).grid(sticky=W,padx=(310,0),row=7,pady=40)
Button(Screen,text="Attachment",bg="red",fg="white",font=("Calibri",20),command=attach,width=16).grid(sticky=W,padx=(580,0),row=7,pady=40)
combo.bind("<<ComboboxSelected>>", callbackFunc)

game="game1"
Screen.resizable(False,False)
Screen.mainloop()

