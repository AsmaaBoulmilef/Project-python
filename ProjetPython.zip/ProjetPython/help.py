import pygame
import random

WIDTH = 1080
HEIGHT = 720
FPS = 30

# definir des couleurs : 
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)
VIOLET = (255,0,255)
MAGENTA = (0,255,255)


# initialiser pygame : 
pygame.init()

# creation de la fenetre : 
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Help")
clock = pygame.time.Clock()

# les images : 
background = pygame.image.load("images/bgGame.jpg").convert()
Windows = []
Windows_rect = []
Games = []
Games_rect = []
titles_games = []
titles_games_rect = []
for i in range(4):
    r = pygame.image.load("images/ic_{}.png".format(i+1)).convert()
    r = pygame.transform.scale(r,(240,170))
    r.set_colorkey(BLACK)
    rr = r.get_rect()
    Games.append(r)
    Games_rect.append(rr)
    w = pygame.image.load("images/Window.png").convert()
    w = pygame.transform.scale(w,(250,200))
    w.set_colorkey(BLACK)
    ww = w.get_rect()
    Windows.append(w)
    Windows_rect.append(ww)
    t = pygame.image.load("images/game{}.png".format(i+1)).convert()
    t.set_colorkey(BLACK)
    tt = t.get_rect()
    titles_games.append(t)
    titles_games_rect.append(tt)

####

g = pygame.image.load("images/ilisiShooterHelp.png").convert()
g_rect = g.get_rect()
g_rect.left = 40
g_rect.top = 230

g1 = pygame.image.load("images/TetrisHelp.png").convert()
g1_rect = g1.get_rect()
g1_rect.left = 40
g1_rect.top = 230

g2 = pygame.image.load("images/SpaceWarHelp.png").convert()
g2_rect = g2.get_rect()
g2_rect.left = 40
g2_rect.top = 230

g3 = pygame.image.load("images/2048Help.png").convert()
g3_rect = g3.get_rect()
g3_rect.left = 40
g3_rect.top = 230


x = 270 
for i in range(4):
    Games_rect[i].top = 35
    Games_rect[i].left = i*x + 15
    Windows_rect[i].top = 10
    Windows_rect[i].left = i*x + 10
    titles_games_rect[i].left = 10
    titles_games_rect[i].top = 230

# la boucle du jeu : 
choice = 0
running = True
while running:
    
    # keep loop running at the right speed : 
    clock.tick(FPS)

    # events:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.MOUSEBUTTONUP :
            pos = event.pos 
            for i in range(4):
                if Games_rect[i].collidepoint(pos):
                    choice = i 
                    break

    # update : 
    

    # draw /  render : 
    screen.fill(BLACK)
    
    screen.blit(background,(0,0))
    
    if choice == 0 : 
        screen.blit(g,g_rect)
    elif choice == 1:
        screen.blit(g1,g1_rect)
    elif choice == 2:
        screen.blit(g2,g2_rect)
    else:
        screen.blit(g3,g3_rect)
    for i in range(4):
        screen.blit(Windows[i],Windows_rect[i])
        screen.blit(Games[i],Games_rect[i])
    
    # after drawing everything, flip the display : 
    pygame.display.flip()

pygame.quit()