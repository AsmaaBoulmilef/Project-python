import pygame
import random
import sys
import os
from os import *

WIDTH = 1080
HEIGHT = 720
FPS = 60

# definir des couleurs : 
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
YELLOW = (255,255,0)
VIOLET = (255,0,255)
MAGENTA = (0,255,255)

# initialiser pygame : 
pygame.init()
pygame.mixer.init()

# ch7al dle wa9t yb9a sla7 nadi :  
POWERUP_TIME = 4000

# fin 7at L3aybatikat :
game_folder = os.path.dirname(__file__)
images_folder = os.path.join(game_folder,"images")
sounds_folder = os.path.join(game_folder,"sounds") 

# utiliser "font" :
font_name = pygame.font.match_font('arial')
# fonction d'ecriture d'un text : 
def draw_text(surf, text, size, x, y):
    font = pygame.font.Font(font_name,size)
    text_surface = font.render(text, True, WHITE)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x,y)
    surf.blit(text_surface, text_rect)

# ajouter enemy : 
def new_enemy():
    e  = Enemy()
    all_sprites.add(e)
    enemies.add(e)

# la barre de vie : 
def draw_shield_bar(surf, x, y, pct):
    if pct < 0 :
        pct = 0
    BAR_WIDTH = 250
    BAR_HEIGHT = 25
    fill = (pct/100)*BAR_WIDTH
    outline_rect = pygame.Rect(x,y, BAR_WIDTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surf, GREEN, fill_rect)
    pygame.draw.rect(surf, WHITE, outline_rect, 2)

# draw explosion : 
def draw_explosion(expl_type):
    expl = Explosion(hit.rect.center, expl_type)
    all_sprites.add(expl)

position_lives = [0,50,100]
# draw lives : 
def draw_lives(surf, x, y, lives, img):
    for i in range(lives):
        img_rect = img.get_rect()
        img_rect.x = x + position_lives[i]
        img_rect.y = y
        surf.blit(img,img_rect)

# draw game over screen : 
def show_game_over_screen():
    global screen
    pygame.mixer.music.stop()
    screen.blit(background,background_rect)
    i = pygame.image.load(os.path.join(images_folder,"asteroid-icon.png")).convert()
    i.set_colorkey(BLACK)
    i_rect = i.get_rect()
    i_rect.bottom , i_rect.centerx = HEIGHT/2 -10 , WIDTH / 2
    screen.blit(i,i_rect)
    draw_text(screen," ILISI SHOOTER ",64,WIDTH/2,HEIGHT/2)
    draw_text(screen," Press Any Key to Start ",24,WIDTH/2,HEIGHT*0.63)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.KEYUP:
                waiting = False

# player class : 
class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(player_img,(100,80))
        self.image.set_colorkey(BLACK)
        self.rect  = self.image.get_rect()
        self.radius = int(self.rect.width/3)
        #pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
        self.rect.centery = HEIGHT/2
        self.rect.left = 10
        self.speedy = 0
        self.shield = 100
        self.shoot_delay = 200
        self.last_shot = pygame.time.get_ticks()
        self.lives = 3 
        self.hidden = False
        self.hide_timer = pygame.time.get_ticks()
        self.power = 1
        self.power_timer = pygame.time.get_ticks()

    def update(self):

        if self.power >= 2 and pygame.time.get_ticks() - self.power_timer > POWERUP_TIME : 
            self.power -= 1
            self.power_timer = pygame.time.get_ticks()

        if self.hidden and pygame.time.get_ticks() - self.hide_timer > 1000:
            self.hidden = False
            self.rect.centery = HEIGHT/2
            self.rect.left = 10

        self.speedy = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_UP] :
            self.speedy = -5
        if keystate[pygame.K_DOWN]:
            self.speedy = 5
        if keystate[pygame.K_SPACE]:
            self.shoot()
        if self.rect.top < 0 : 
            self.rect.top = 0
        if self.rect.bottom > HEIGHT : 
            self.rect.bottom = HEIGHT
        self.rect.y += self.speedy
    
    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            if self.power == 1 :
                bullet = Bullet(self.rect.right, self.rect.centery)
                all_sprites.add(bullet)
                bullets.add(bullet)
                laser_shoot.play()
            if self.power >= 2 :
                bullet1 = Bullet(self.rect.right, self.rect.top)
                bullet2 = Bullet(self.rect.right, self.rect.bottom)
                all_sprites.add(bullet1)
                all_sprites.add(bullet2)
                bullets.add(bullet1)
                laser_shoot.play()
                bullets.add(bullet2)
                laser_shoot.play()
    
    def hide(self):
        self.hidden = True
        self.hide_timer = pygame.time.get_ticks()
        self.rect.center = (2400 , HEIGHT/2)
    
    def powerup(self):
        self.power += 1
        self.power_timer = pygame.time.get_ticks()


# class enemy :         
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image_original = random.choice(asteroid_images)
        self.image_original.set_colorkey(WHITE)
        self.image = self.image_original.copy()
        self.rect  = self.image.get_rect()
        self.radius = int(self.rect.width/2)
        #pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
        self.rect.x = random.randrange(WIDTH, WIDTH + 40)
        self.rect.y = random.randrange(HEIGHT)
        self.speedx = random.randrange(1,8)
        self.speedy = random.randrange(-3,3)
        self.rot = 0
        self.rot_speed = random.randrange(-8,8)
        self.last_update = pygame.time.get_ticks()
    
    def rotate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 50 : 
            self.last_update = now
            self.rot = (self.rot + self.rot_speed) % 360
            new_image = pygame.transform.rotate(self.image_original, self.rot)
            old_center = self.rect.center
            self.image = new_image
            self.rect = self.image.get_rect()
            self.rect.center = old_center

    def update(self):
        self.rotate()
        self.rect.x -= self.speedx
        self.rect.y += self.speedy 
        if self.rect.right < -10 or self.rect.bottom < -20 or self.rect.top > HEIGHT+20:
            self.rect.x = random.randrange(WIDTH, WIDTH + 40)
            self.rect.y = random.randrange(HEIGHT)
            self.speedx = random.randrange(5,12) 
        

# class l9ortass : 
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x , y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(bullet_img,(60,10))
        self.image.set_colorkey(BLACK)
        self.rect  = self.image.get_rect()
        self.rect.left = x
        self.rect.centery = y
        self.speedx = 20
    
    def update(self):
        self.rect.x += self.speedx
        if self.rect.left > WIDTH:
            self.kill()


# class l9ass :
class Power(pygame.sprite.Sprite):
    def __init__(self, center):
        pygame.sprite.Sprite.__init__(self)
        self.type = random.choice(['shield','gun'])
        self.image = powerups_images[self.type]
        self.image.set_colorkey(BLACK)
        self.rect  = self.image.get_rect()
        self.rect.center = center
        self.speedx = -2.5
    
    def update(self):
        self.rect.x += self.speedx
        if self.rect.right < 0:
            self.kill()


#class tfergui3 :
class Explosion(pygame.sprite.Sprite):
    def __init__(self, center, size):
        pygame.sprite.Sprite.__init__(self)
        self.size = size
        self.image = explosion_anim[self.size][0]
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.frame = 0
        self.last_update = pygame.time.get_ticks()
        self.frame_rate = 50
    
    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == len(explosion_anim[self.size]):
                self.kill()
            else:
                center = self.rect.center
                self.image = explosion_anim[self.size][self.frame]
                self.rect = self.image.get_rect()
                self.rect.center = center





# creation de la fenetre : 
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Ilisi Shooter")
clock = pygame.time.Clock()

# les images bach ankhdem :
background = pygame.image.load(os.path.join(images_folder,"bgGame.jpg")).convert()
background_rect = background.get_rect()
player_img = pygame.image.load(os.path.join(images_folder,"spaceship.png")).convert()
player_mini_img = pygame.transform.scale(player_img,(60,48))
player_mini_img.set_colorkey(BLACK)
enemy_img = pygame.image.load(os.path.join(images_folder,"asteroid_medium.png")).convert()
bullet_img = pygame.image.load(os.path.join(images_folder,"laser.png")).convert()

asteroid_images = []
asteroid_images.append(pygame.image.load('images/asteroid_big.png').convert())
asteroid_images.append(pygame.image.load('images/asteroid_medium.png').convert())
asteroid_images.append(pygame.image.load('images/asteroid_small.png').convert())

explosion_anim = {}
explosion_anim['lg'] = []
explosion_anim['md'] = []
explosion_anim['sm'] = []
explosion_anim['pl'] = []
for i in range(7) : 
    filename = 'e_{}.png'.format(i+1)
    img = pygame.image.load(os.path.join(images_folder,filename)).convert()
    img.set_colorkey(WHITE)
    img_lg = pygame.transform.scale(img,(100,100))
    explosion_anim['lg'].append(img_lg)
    img_md = pygame.transform.scale(img,(50,50))
    explosion_anim['md'].append(img_md)
    img_sm = pygame.transform.scale(img,(30,30))
    explosion_anim['sm'].append(img_sm)
    img_pl = pygame.transform.scale(img,(130,130))
    explosion_anim['pl'].append(img_pl)

powerups_images = {}
powerups_images['shield'] =  pygame.image.load(os.path.join(images_folder,"shield.png")).convert()
powerups_images['gun'] =  pygame.image.load(os.path.join(images_folder,"gun.png")).convert()

# les sons bach khedam : 
bg_music = pygame.mixer.music.load(os.path.join(sounds_folder,'mainTheme.mp3'))
laser_shoot = pygame.mixer.Sound(os.path.join(sounds_folder,"laser.mp3"))
laser_shoot.set_volume(0.8)
explosion_sounds = []
for i in range(3) : 
    n = "explosion{}.wav".format(i+1)
    explosion_sounds.append(pygame.mixer.Sound(os.path.join(sounds_folder,n)))
    explosion_sounds[i].set_volume(.10)

pygame.mixer.music.set_volume(0.15)


"""
# les elements du jeu : 
all_sprites = pygame.sprite.Group() 
enemies = pygame.sprite.Group()
bullets = pygame.sprite.Group()
powerups = pygame.sprite.Group()
player = Player()
all_sprites.add(player)
for i in range(8):
    new_enemy() 
  
# score : 
score = 0

# for scrolling background
x_d = 0 
"""
# death explosion : 



# la boucle du jeu : 
running = True
Game_over = True
while running:
    
    if Game_over :
        show_game_over_screen()
        Game_over = False
        all_sprites = pygame.sprite.Group() 
        enemies = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        powerups = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)
        for i in range(8):
            new_enemy() 
        # score : 
        score = 0
        # for scrolling background
        x_d = 0
        pygame.mixer.music.play(-1) 

    # keep loop running at the right speed : 
    clock.tick(FPS)

    # events:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        

    # update : 
    all_sprites.update()

    # wach 9artessna chi haja : 
    hits = pygame.sprite.groupcollide(enemies, bullets, True, True)
    for hit in hits: 
        score += 100 - hit.radius
        random.choice(explosion_sounds).play()
        if hit.radius == 50 : 
            draw_explosion('lg')
        elif hit.radius == 25 : 
            draw_explosion('md')
        else:
            draw_explosion('sm')  
        if random.random() > 0.9 : 
            pow = Power(hit.rect.center)
            all_sprites.add(pow)
            powerups.add(pow) 
        new_enemy()

    # wach khebtatna chi haja : 
    hits  = pygame.sprite.spritecollide(player, enemies, True, pygame.sprite.collide_circle)
    for hit in hits : 
        player.shield -= hit.radius
        random.choice(explosion_sounds).play()
        if hit.radius == 50 : 
            draw_explosion('lg')
        elif hit.radius == 25 : 
            draw_explosion('md')
        else:
            draw_explosion('sm')
        new_enemy()
        if player.shield <= 0 : 
            death_explosion = Explosion(player.rect.center, 'pl')
            all_sprites.add(death_explosion)
            random.choice(explosion_sounds).play()
            player.hide()
            player.lives -= 1
            player.shield = 100

    # wach klina chi haja :
    hits  = pygame.sprite.spritecollide(player, powerups, True)
    for hit in hits:
        if hit.type == 'shield':
            player.shield += 20
            if player.shield >= 100:
                player.shield = 100
        if hit.type == 'gun' : 
            player.powerup()

    # ila metna ou animation ta3 akhir_tfergui3a salat : 
    if player.lives==0 and not death_explosion.alive():
        Game_over = True

    # draw /  render : 
    screen.fill(BLACK)

    rel_x = x_d % background_rect.width
    screen.blit(background,(rel_x - background_rect.width,0))
    if rel_x < WIDTH : 
        screen.blit(background,(rel_x,0))
    x_d -= 2

    all_sprites.draw(screen)
    draw_text(screen, 'SCORE: '+ str(score), 36, WIDTH/2, 10)
    draw_shield_bar(screen, 10,16,player.shield)
    draw_lives(screen, WIDTH - 200, 10, player.lives, player_mini_img)
    # after drawing everything, flip the display : 
    pygame.display.flip()

pygame.quit()