import pygame
import os
from pygame.locals import *
import sys

clicked =  False

# display game over interface
    
pygame.init()
screen = pygame.display.set_mode((800, 600)) #create window 
pygame.display.set_caption('GAME OVER')      #set name of window
        
        # Icon
icon = pygame.image.load("./assests/img/rocket.png")
pygame.display.set_icon(icon)

pygame.display.flip()      #will update the contents of the entire display.
font = pygame.font.SysFont('Constantia', 30)  # font text and size

    #define images
bg = pygame.image.load('./assests/img/bg.png')
go = pygame.image.load('./assests/img/go.png')
    #cadre button
black = (0, 0, 0)
white = (255, 255, 255)

    # button
class button():

        #colours for button, text, x, y, width and height
    button_col = (100, 100, 100)  
    hover_col = (127, 127, 127)
    click_col = (65, 65, 65)
    text_col = black
    width = 180
    height = 70

    def __init__(self, x, y, text):
        self.x = x
        self.y = y
        self.text = text

        #For change position of buttons
    def change(self, w, h): 
        self.width = w
        self.height = h

            
        #draw button
    def draw_button(self):
        global clicked
        action = False

            #get mouse position
        pos = pygame.mouse.get_pos()

            #create pygame Rect object for the button
        button_rect = Rect(self.x, self.y, self.width, self.height) #pygame object for storing rectangular coordinates

            #check mouseover and clicked conditions
        if button_rect.collidepoint(pos):    # test if a "pos" is inside a rectangle
            if pygame.mouse.get_pressed()[0] == 1:  # get the state of the mouse buttons ([0]: coor x)
                clicked = True
                pygame.draw.rect(screen, self.click_col, button_rect) # draw with click color
            elif pygame.mouse.get_pressed()[0] == 0 and clicked == True:
                clicked = False
                action = True
            else:
                pygame.draw.rect(screen, self.hover_col, button_rect) # mouse inside rect without click
        else:
            pygame.draw.rect(screen, self.button_col, button_rect)

            #add shading to button
                # surface, color, start_pos, end_pos, width
        pygame.draw.line(screen, white, (self.x, self.y), (self.x + self.width, self.y), 2)
        pygame.draw.line(screen, white, (self.x, self.y), (self.x, self.y + self.height), 2)
        pygame.draw.line(screen, black, (self.x, self.y + self.height), (self.x + self.width, self.y + self.height), 2)
        pygame.draw.line(screen, black, (self.x + self.width, self.y), (self.x + self.width, self.y + self.height), 2)

            #add text to button
        text_img = font.render(self.text, True, self.text_col) # return text with color
        text_len = text_img.get_width()  # get width button
        screen.blit(text_img, (self.x + int(self.width / 2) - int(text_len / 2), self.y + 25))
        return action

    # init play and quit buttons
play = button(150, 450, '< Again')
quit = button(505, 450, 'Quit >')

run = True
while run:  
    screen.blit(bg,(0,0))    # set background
    screen.blit(go,(80,40))  # set game over image

    #read file
    f = open("scores.txt", "r")
    scores = f.read().splitlines()
    
        # Result of the game (winner and score)
    if (scores[0] == scores[1]):
        valeur = scores[0]
        win = "         No winner"
    elif(scores[0] < scores[1]):
        valeur = scores[1]
        win = "The winner is : Player 2"
    else:
        valeur = scores[0]
        win = "The winner is : Player 1"

        # set text winner in screen 
    
    winner = font.render(win, True, (255, 255, 255))
    screen.blit(winner, (260, 280))
        
        # set winner score in screen
    score = font.render("Score: " + str(valeur), True, (255, 255, 255))
    screen.blit(score, (350, 330))
    
    if play.draw_button(): # click again button
        print('Again')
        pygame.display.quit()
        os.system('python main.py') # let's go to play!
        sys.exit()
    elif quit.draw_button(): # click quit button
        print('Quit')
        run = False
        pygame.display.quit()
        sys.exit()
    
    pygame.init()   
    # test click quit button
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False 
            

        # Update parts of the screen 
    pygame.display.flip() 

