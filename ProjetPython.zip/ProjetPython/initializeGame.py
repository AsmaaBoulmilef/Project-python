import pygame
from pygame import mixer

# initialize the pygame
pygame.init()

# creating the game window
screen = pygame.display.set_mode((800, 600))

# Title
pygame.display.set_caption("SPACE WAR")

# Icon
icon = pygame.image.load("./assests/img/rocket.png")
pygame.display.set_icon(icon)

# Font text
font = pygame.font.SysFont('Constantia', 30)

# Charge image boom
boom = pygame.image.load("./assests/img/fire.png")
boom = pygame.transform.scale(boom, (50, 50))

# Charge Images Players
playerImg = pygame.image.load("./assests/img/player1.png")
playerImg = pygame.transform.scale(playerImg, (64, 64))
playerImg2 = pygame.image.load("./assests/img/player2.png")
playerImg2 = pygame.transform.scale(playerImg2, (64, 64))

# Info Enemies
number_of_enemies = 15
ENEMY_MOVEMENT_X = 1.3

# Background image
backgroundImg = pygame.image.load("./assests/img/background.jpg")

# Background sound
mixer.music.load("./assests/sounds/background-track.mp3")
mixer.music.play(-1) # The music repeats indefinately if this argument is set to -1

# starting level
level = 1

# starting time
starter_time = pygame.time.get_ticks() #returns the number of milliseconds since pygame.init() was called